/* Generated automatically. */
static const char configuration_arguments[] = "./configure --prefix=/buildroot-2022.05/output/host --sysconfdir=/buildroot-2022.05/output/host/etc --enable-static --target=i586-buildroot-linux-gnu --with-sysroot=/buildroot-2022.05/output/host/i586-buildroot-linux-gnu/sysroot --enable-__cxa_atexit --with-gnu-ld --disable-libssp --disable-multilib --disable-decimal-float --with-gmp=/buildroot-2022.05/output/host --with-mpc=/buildroot-2022.05/output/host --with-mpfr=/buildroot-2022.05/output/host --with-pkgversion='Buildroot 2022.05' --with-bugurl=http://bugs.buildroot.net/ --without-zstd --enable-libquadmath --enable-tls --enable-threads --without-isl --without-cloog --with-arch=i586 --enable-languages=c --with-build-time-tools=/buildroot-2022.05/output/host/i586-buildroot-linux-gnu/bin --enable-shared --disable-libgomp";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "cpu", "pentium" }, { "arch", "i586" } };
