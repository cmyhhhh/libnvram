/* Generated automatically. */
static const char configuration_arguments[] = "./configure --prefix=/buildroot-2022.05/output/host --sysconfdir=/buildroot-2022.05/output/host/etc --enable-static --target=mips-buildroot-linux-gnu --with-sysroot=/buildroot-2022.05/output/host/mips-buildroot-linux-gnu/sysroot --enable-__cxa_atexit --with-gnu-ld --disable-libssp --disable-multilib --disable-decimal-float --with-gmp=/buildroot-2022.05/output/host --with-mpc=/buildroot-2022.05/output/host --with-mpfr=/buildroot-2022.05/output/host --with-pkgversion='Buildroot 2022.05' --with-bugurl=http://bugs.buildroot.net/ --without-zstd --disable-libquadmath --disable-libquadmath-support --enable-tls --enable-threads --without-isl --without-cloog --with-float=soft --with-arch=mips32 --with-abi=32 --with-nan=legacy --enable-languages=c --with-build-time-tools=/buildroot-2022.05/output/host/mips-buildroot-linux-gnu/bin --enable-shared --disable-libgomp";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "abi", "32" }, { "arch", "mips32" }, { "float", "soft" }, { "nan", "legacy" }, { "llsc", "llsc" } };
