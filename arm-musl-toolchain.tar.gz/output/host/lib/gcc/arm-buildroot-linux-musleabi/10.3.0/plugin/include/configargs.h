/* Generated automatically. */
static const char configuration_arguments[] = "./configure --prefix=/buildroot-2022.05/output/host --sysconfdir=/buildroot-2022.05/output/host/etc --enable-static --target=arm-buildroot-linux-musleabi --with-sysroot=/buildroot-2022.05/output/host/arm-buildroot-linux-musleabi/sysroot --enable-__cxa_atexit --with-gnu-ld --disable-libssp --disable-multilib --disable-decimal-float --with-gmp=/buildroot-2022.05/output/host --with-mpc=/buildroot-2022.05/output/host --with-mpfr=/buildroot-2022.05/output/host --with-pkgversion='Buildroot 2022.05' --with-bugurl=http://bugs.buildroot.net/ --without-zstd --disable-libmpx --disable-libquadmath --disable-libquadmath-support --disable-libsanitizer --enable-tls --enable-threads --without-isl --without-cloog --with-float=soft --with-abi=aapcs-linux --with-cpu=arm926ej-s --with-float=soft --with-mode=arm --enable-languages=c --with-build-time-tools=/buildroot-2022.05/output/host/arm-buildroot-linux-musleabi/bin --enable-shared --disable-libgomp";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "abi", "aapcs-linux" }, { "cpu", "arm926ej-s" }, { "float", "soft" }, { "mode", "arm" }, { "tls", "gnu" } };
